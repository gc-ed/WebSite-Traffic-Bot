# memory.md — Agent Persistent Memory

> **Agent rule:** This file is your long-term memory. Read it at the start of EVERY session. Append a new entry at the end of EVERY session. Never delete past entries. If this file is empty or missing, that means this is Session 1 — initialize it now.

---

## 🧭 How to Use This File

- **On session start:** Read ALL entries below. Reconstruct your understanding of project state.
- **On session end:** Append a new `## Session [N]` block (see format below).
- **On task completion:** Note it here AND update `TASKS.md`.
- **On discovery:** If you find something unexpected (a bug, a missing file, a config issue), log it here immediately.

---

## 📋 Project State Summary

> *Agent: Keep this section updated. Rewrite it each session to reflect current reality.*

| Field                  | Value                                  |
|------------------------|----------------------------------------|
| Project name           | Traffic Bot                            |
| Current phase          | 🔴 Setup — not yet started             |
| Last active session    | None                                   |
| Docker status          | ❌ Not built                           |
| Bot status             | ❌ Not implemented                     |
| Target URL             | ⚠️ Not configured — set in `.env`      |
| Last traffic run       | Never                                  |
| KPI status             | ⚠️ No data yet                         |
| Blockers               | None                                   |

---

## 📊 KPI Snapshot

> *Agent: Update after every traffic run.*

| KPI                    | Target     | Last Measured | Status  |
|------------------------|------------|---------------|---------|
| Sessions / day         | ≥ 100      | —             | ⚠️ N/A  |
| Pages / session        | ≥ 3        | —             | ⚠️ N/A  |
| Avg. session duration  | ≥ 45s      | —             | ⚠️ N/A  |
| Bounce rate            | ≤ 30%      | —             | ⚠️ N/A  |
| Route coverage         | ≥ 80%      | —             | ⚠️ N/A  |

---

## 🗒️ Session Log

---

### Session 1 — [AGENT: replace with ISO timestamp, e.g. 2026-05-14T10:00:00Z]

**What I did this session:**
- [ ] Read `AGENTS.md` ✅
- [ ] Read `TASKS.md` ✅
- [ ] Read `memory.md` ✅ (this is the first entry)
- [ ] [List every action taken]

**Tasks completed:**
- *(none yet)*

**Tasks moved to IN PROGRESS:**
- *(none yet)*

**Tasks blocked:**
- *(none)*

**Discoveries / notes:**
- Project is freshly initialized. No `.env`, no `config/targets.json`, no bot code yet.
- First action should be TASK-001: create `.env` with all required variables.

**Files created/modified this session:**
- `AGENTS.md` — created (initial version)
- `TASKS.md` — created (initial task list)
- `memory.md` — created (this file)

**Next session should start with:**
- Pick up TASK-001 from `TASKS.md`
- Confirm `TARGET_URL` is known before proceeding

---

### Session 2 — [AGENT: replace with timestamp]

**What I did this session:**
*(Agent: fill this in)*

**Tasks completed:**
*(Agent: list completed tasks with TASK-IDs)*

**Tasks moved to IN PROGRESS:**
*(Agent: list)*

**Tasks blocked:**
*(Agent: list with reason)*

**Discoveries / notes:**
*(Agent: anything unexpected, decisions made, trade-offs chosen)*

**Files created/modified this session:**
*(Agent: list)*

**Next session should start with:**
*(Agent: brief note on where to pick up)*

---

<!-- AGENT: Add new session blocks below this line. Copy the template above. -->

---

## 🔧 Decisions Log

> *Agent: When you make an architectural or configuration decision, record it here so future sessions understand why.*

| Date | Decision | Reason |
|------|----------|--------|
| *(session 1)* | Used Playwright over Selenium | Better headless Chrome support, async-native, easier scroll simulation |
| *(session 1)* | Used `python:3.11-slim` as base image | Small image size, good Playwright support |
| *(session 1)* | KPI log format: JSON lines (`.jsonl`) | Easier to parse programmatically than plain text |

---

## ⚠️ Known Issues

> *Agent: Log bugs, gaps, or concerns here. Mark resolved ones with ✅.*

| ID     | Issue                          | Status      | Session Found |
|--------|-------------------------------|-------------|---------------|
| *(none yet)* | —                        | —           | —             |

---

## 📦 Dependencies Reference

> *Agent: Keep this updated as you install things.*

| Package          | Version   | Purpose                          |
|------------------|-----------|----------------------------------|
| `playwright`     | latest    | Browser automation               |
| `python-dotenv`  | latest    | Load `.env` into environment     |
| `httpx`          | latest    | Optional: lightweight HTTP calls |
| `loguru`         | latest    | Structured logging               |

---

*This file is maintained automatically by the AI agent. Do not manually edit past sessions.*
