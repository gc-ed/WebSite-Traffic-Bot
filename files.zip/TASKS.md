# TASKS.md — Agent Task Tracker

> **Agent rule:** Always read this file at session start. Pick the first `TODO` task. Update status as you work. Never leave a task in `IN PROGRESS` at session end — either complete it or mark it `BLOCKED`.

---

## 🔴 TODO

- [ ] **TASK-001** — Create `.env` file with all required environment variables  
  *Priority: HIGH | Depends on: nothing*  
  Fill in `TARGET_URL`, `SESSIONS_PER_RUN`, `PAGES_PER_SESSION`, `DWELL_TIME_MIN`, `DWELL_TIME_MAX`, and all other variables listed in `AGENTS.md`.

- [ ] **TASK-002** — Create `config/targets.json` with full list of page routes to visit  
  *Priority: HIGH | Depends on: TASK-001 (TARGET_URL must be known)*  
  Include homepage, all major section pages, and any pages important to KPI tracking.

- [ ] **TASK-003** — Write `bot/config.py` — reads and validates all env vars  
  *Priority: HIGH | Depends on: TASK-001*  
  Should raise clear errors if required vars are missing. Export a `Config` dataclass.

- [ ] **TASK-004** — Write `bot/browser.py` — browser/session simulation module  
  *Priority: HIGH | Depends on: TASK-003*  
  Use Playwright or Selenium. Must support: page visits, scroll simulation, dwell time, user-agent rotation, optional proxy support.

- [ ] **TASK-005** — Write `bot/logger.py` — KPI logging module  
  *Priority: MEDIUM | Depends on: TASK-003*  
  Log each session's: pages visited, total duration, paths, user-agent, proxy used, timestamp. Write to `KPI_LOG_PATH`.

- [ ] **TASK-006** — Write `bot/main.py` — entry point  
  *Priority: HIGH | Depends on: TASK-004, TASK-005*  
  Orchestrates N sessions per run. Calls browser + logger. Handles errors gracefully.

- [ ] **TASK-007** — Write `Dockerfile`  
  *Priority: HIGH | Depends on: TASK-006*  
  Base: `python:3.11-slim` + Playwright/Selenium + Chromium. Install deps. Set entrypoint to `bot/main.py`.

- [ ] **TASK-008** — Write `docker-compose.yml`  
  *Priority: MEDIUM | Depends on: TASK-007*  
  Mount `./logs:/logs` volume. Load `.env`. Add restart policy. Optional: cron-style scheduling via `ofelia` or loop sleep.

- [ ] **TASK-009** — Test Docker build locally  
  *Priority: HIGH | Depends on: TASK-008*  
  Run `docker build` and verify no errors. Document any issues in `memory.md`.

- [ ] **TASK-010** — Run first live traffic test  
  *Priority: HIGH | Depends on: TASK-009*  
  Execute one full run against `TARGET_URL`. Verify KPI log output. Check analytics dashboard to confirm traffic was recorded.

- [ ] **TASK-011** — Tune KPI parameters to hit targets  
  *Priority: MEDIUM | Depends on: TASK-010*  
  Adjust `SESSIONS_PER_RUN`, `DWELL_TIME_MIN/MAX`, `PAGES_PER_SESSION` based on initial results. Document changes in `memory.md`.

- [ ] **TASK-012** — Set up automated scheduling  
  *Priority: LOW | Depends on: TASK-011*  
  Configure Docker to run on a schedule (cron job, GitHub Actions, or loop-with-sleep). Target: N runs/day to meet daily session KPI.

- [ ] **TASK-013** — Add proxy rotation support  
  *Priority: LOW | Depends on: TASK-004*  
  Implement proxy cycling from `PROXY_LIST` env var. Verify IPs are being rotated via logs.

- [ ] **TASK-014** — Write `README.md` — human-readable setup guide  
  *Priority: LOW | Depends on: TASK-008*  
  Covers: prerequisites, `.env` setup, build, run, log reading, and KPI monitoring.

---

## 🟡 IN PROGRESS

*(Agent: move tasks here when you start working on them)*

---

## 🟢 DONE

*(Agent: move tasks here when fully completed. Include completion timestamp.)*

---

## 🔵 BLOCKED

*(Agent: move tasks here if blocked. Explain the blocker clearly.)*

---

## 📝 Notes for Agent

- Tasks are roughly ordered by dependency — do them top to bottom unless blocked.
- If you discover a new task while working, add it to `TODO` with a `TASK-NNN` ID.
- Never delete tasks — only move them between sections.
- After each session, the `DONE` section should grow.

---

*Last updated by: [AGENT — update on each session with timestamp]*
